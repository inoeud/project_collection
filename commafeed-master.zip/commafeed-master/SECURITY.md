# Security Policy

## Reporting a Vulnerability

If you found a vulnerability that you deem too sensitive to disclose publicly in a Github issue, please send an email at jeremiepanzer at gmail dot com.
Thanks !
