package com.commafeed.frontend.model.request;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@SuppressWarnings("serial")
@ApiModel(description = "Mark Request")
@Data
public class MarkRequest implements Serializable {

	@ApiModelProperty(value = "entry id, category id, 'all' or 'starred'", required = true)
	@NotEmpty
	@Size(max = 128)
	private String id;

	@ApiModelProperty(value = "mark as read or unread", required = true)
	private boolean read;

	@ApiModelProperty(
			value = "only entries older than this, pass the timestamp you got from the entry list to prevent marking an entry that was not retrieved",
			required = false)
	private Long olderThan;

	@ApiModelProperty(value = "only mark read if a feed has these keywords in the title or rss content", required = false)
	@Size(max = 128)
	private String keywords;

	@ApiModelProperty(value = "if marking a category or 'all', exclude those subscriptions from the marking", required = false)
	private List<Long> excludedSubscriptions;

}
